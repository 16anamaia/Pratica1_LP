package br.com.pratica2;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);

        System.out.println("Digite o valor inicial do Rendimento");
        double vrInicial = ler.nextDouble();

        System.out.println("Digite a taxa de juros:");
        double txJuros = ler.nextDouble();

        System.out.println("Digite o numero de meses para o Rendimento");
        int nullMeses = ler.nextInt();

        rendimento r1 = new rendimento(vrInicial,txJuros,nullMeses);
        r1.calcularRendimento();

    }
}
